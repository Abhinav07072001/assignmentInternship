const mongoose = require('mongoose');

const loanSchema = new mongoose.Schema({
  customer_id: { type: Number, required: true },
  loan_amount: { type: Number, required: true },
  loan_period: { type: Number, required: true },
  interest_rate: { type: Number, required: true },
  total_amount: { type: Number, required: true },
  monthly_emi: { type: Number, required: true },
  emi_left: { type: Number, required: true },
  payments: [{
    payment_date: { type: Date, default: Date.now },
    payment_amount: { type: Number, required: true },
    payment_type: { type: String, enum: ['EMI', 'LUMP_SUM'], required: true },
  }]
});

module.exports = mongoose.model('Loan', loanSchema);
