    const express = require('express');
    const router = express.Router();
    const Loan = require('../models/loan');

    // Helper function to calculate interest, total amount, and EMI
    function calculateLoanDetails(P, N, R) {
        const monthlyRate = R / (12 * 100); // Convert annual interest rate to monthly rate
        const numberOfMonths = N * 12;
    
        // Calculate total amount (Principal + Interest using compound interest)
        const total_amount = P * Math.pow(1 + monthlyRate, numberOfMonths);
    
        // Calculate EMI using the formula
        const emi = (P * monthlyRate * Math.pow(1 + monthlyRate, numberOfMonths)) / (Math.pow(1 + monthlyRate, numberOfMonths) - 1);
    
        // Return total amount and EMI rounded to 2 decimal places
        return { 
            total_amount: total_amount.toFixed(2), 
            emi: emi.toFixed(2) 
        };
    }

    // LEND: Create a new loan
    router.post('/lend', async (req, res) => {
    const { customer_id, loan_amount, loan_period, rate_of_interest } = req.body;
    const { total_amount, emi } = calculateLoanDetails(loan_amount, loan_period, rate_of_interest);

    const newLoan = new Loan({
        customer_id,
        loan_amount,
        loan_period,
        interest_rate: rate_of_interest,
        total_amount,
        monthly_emi: emi,
        emi_left: loan_period * 12,
        payments: []
    });

    try {
        const savedLoan = await newLoan.save();
        res.status(201).json({ total_amount: savedLoan.total_amount, monthly_emi: savedLoan.monthly_emi });
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
    });

    // PAYMENT: Make a loan payment
    router.post('/payment', async (req, res) => {
    const { loan_id, payment_amount } = req.body;
    
    try {
        const loan = await Loan.findById(loan_id);

        if (!loan) {
        return res.status(404).json({ message: 'Loan not found' });
        }

        loan.payments.push({ payment_amount, payment_type: payment_amount >= loan.monthly_emi ? 'LUMP_SUM' : 'EMI' });
        loan.total_amount -= payment_amount;

        if (payment_amount >= loan.monthly_emi) {
        const emi_paid = Math.floor(payment_amount / loan.monthly_emi);
        loan.emi_left -= emi_paid;
        } else {
        loan.emi_left -= 1;
        }

        await loan.save();
        res.status(200).json({ remaining_amount: loan.total_amount, emi_left: loan.emi_left });
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
    });

    // LEDGER: Get all transactions for a loan
    router.get('/ledger/:loan_id', async (req, res) => {
    const { loan_id } = req.params;

    try {
        const loan = await Loan.findById(loan_id);
        if (!loan) {
        return res.status(404).json({ message: 'Loan not found' });
        }
        res.status(200).json({
        transactions: loan.payments,
        balance_amount: loan.total_amount,
        monthly_emi: loan.monthly_emi,
        emi_left: loan.emi_left
        });
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
    });

    // ACCOUNT OVERVIEW: Get all loans for a customer
    router.get('/overview/:customer_id', async (req, res) => {
    const { customer_id } = req.params;

    try {
        const loans = await Loan.find({ customer_id });

        if (loans.length === 0) {
        return res.status(404).json({ message: 'No loans found for this customer' });
        }

        const overview = loans.map(loan => ({
        loan_id: loan._id,
        loan_amount: loan.loan_amount,
        total_amount: loan.total_amount,
        monthly_emi: loan.monthly_emi,
        total_interest: loan.total_amount - loan.loan_amount,
        amount_paid: loan.payments.reduce((sum, payment) => sum + payment.payment_amount, 0),
        emi_left: loan.emi_left
        }));

        res.status(200).json(overview);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
    });

    module.exports = router;
