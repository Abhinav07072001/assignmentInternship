import React from 'react';
import LendLoan from './components/LendLoan';
import Payment from './components/Payment';
import Ledger from './components/Ledger';
import AccountOverview from './components/AccountOverview';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Bank System Frontend</h1>
      <LendLoan />
      <Payment />
      <Ledger />
      <AccountOverview />
    </div>
  );
}

export default App;


