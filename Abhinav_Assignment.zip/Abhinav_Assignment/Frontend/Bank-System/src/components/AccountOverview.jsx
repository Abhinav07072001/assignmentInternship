import React, { useState } from 'react';
import axios from 'axios';

function AccountOverview() {
  const [customerId, setCustomerId] = useState('');
  const [overview, setOverview] = useState(null);

  const handleChange = (e) => {
    setCustomerId(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.get(`http://localhost:3000/loan/overview/${customerId}`)
      .then(res => setOverview(res.data))
      .catch(err => console.error(err));
  };

  return (
    <div>
      <h2>Account Overview</h2>
      <form onSubmit={handleSubmit}>
        <input placeholder="Customer ID" value={customerId} onChange={handleChange} />
        <button type="submit">View Overview</button>
      </form>
      {overview && (
        <div>
          {overview.map((loan, index) => (
            <div key={index}>
              <p>Loan ID: {loan.loan_id}</p>
              <p>Loan Amount: {loan.loan_amount}</p>
              <p>Total Amount: {loan.total_amount}</p>
              <p>Monthly EMI: {loan.monthly_emi}</p>
              <p>Total Interest: {loan.total_interest}</p>
              <p>Amount Paid: {loan.amount_paid}</p>
              <p>EMIs Left: {loan.emi_left}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default AccountOverview;
