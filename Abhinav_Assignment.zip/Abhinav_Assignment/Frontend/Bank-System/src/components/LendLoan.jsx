import React, { useState } from 'react';
import axios from 'axios';

function LendLoan() {
  const [formData, setFormData] = useState({
    customer_id: '',
    loan_amount: '',
    loan_period: '',
    rate_of_interest: ''
  });
  const [response, setResponse] = useState(null);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:3000/loan/lend', formData)
      .then(res => setResponse(res.data))
      .catch(err => console.error(err));
  };

  return (
    <div>
      <h2>Lend Loan</h2>
      <form onSubmit={handleSubmit}>
        <input name="customer_id" placeholder="Customer ID" value={formData.customer_id} onChange={handleChange} />
        <input name="loan_amount" placeholder="Loan Amount" value={formData.loan_amount} onChange={handleChange} />
        <input name="loan_period" placeholder="Loan Period (years)" value={formData.loan_period} onChange={handleChange} />
        <input name="rate_of_interest" placeholder="Interest Rate" value={formData.rate_of_interest} onChange={handleChange} />
        <button type="submit">Lend Loan</button>
      </form>
      {response && (
        <div>
          <p>Total Amount: {response.total_amount}</p>
          <p>Monthly EMI: {response.monthly_emi}</p>
        </div>
      )}
    </div>
  );
}

export default LendLoan;
