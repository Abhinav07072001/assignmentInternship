import React, { useState } from 'react';
import axios from 'axios';

function Ledger() {
  const [loanId, setLoanId] = useState('');
  const [ledger, setLedger] = useState(null);

  const handleChange = (e) => {
    setLoanId(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.get(`http://localhost:3000/loan/ledger/${loanId}`)
      .then(res => setLedger(res.data))
      .catch(err => console.error(err));
  };

  return (
    <div>
      <h2>View Loan Ledger</h2>
      <form onSubmit={handleSubmit}>
        <input placeholder="Loan ID" value={loanId} onChange={handleChange} />
        <button type="submit">View Ledger</button>
      </form>
      {ledger && (
        <div>
          <p>Balance Amount: {ledger.balance_amount}</p>
          <p>Monthly EMI: {ledger.monthly_emi}</p>
          <p>EMIs Left: {ledger.emi_left}</p>
          <h3>Transactions</h3>
          <ul>
            {ledger.transactions.map((transaction, index) => (
              <li key={index}>
                {transaction.payment_type}: {transaction.payment_amount} on {transaction.payment_date}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default Ledger;
