import React, { useState } from 'react';
import axios from 'axios';

function Payment() {
  const [formData, setFormData] = useState({
    loan_id: '',
    payment_amount: ''
  });
  const [response, setResponse] = useState(null);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:3000/loan/payment', formData)
      .then(res => setResponse(res.data))
      .catch(err => console.error(err));
  };

  return (
    <div>
      <h2>Make Payment</h2>
      <form onSubmit={handleSubmit}>
        <input name="loan_id" placeholder="Loan ID" value={formData.loan_id} onChange={handleChange} />
        <input name="payment_amount" placeholder="Payment Amount" value={formData.payment_amount} onChange={handleChange} />
        <button type="submit">Submit Payment</button>
      </form>
      {response && (
        <div>
          <p>Remaining Amount: {response.remaining_amount}</p>
          <p>EMIs Left: {response.emi_left}</p>
        </div>
      )}
    </div>
  );
}

export default Payment;
