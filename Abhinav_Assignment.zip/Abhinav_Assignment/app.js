const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const loanRoutes = require('./routes/loan');
const cors = require('cors');

const app = express();
app.use(cors()); // Enable CORS for all routes
app.use(express.json());


// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/bank_system', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log('MongoDB connected'))
  .catch((err) => console.log('Error:', err));

// Loan routes
app.use('/loan', loanRoutes);

// Start server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
